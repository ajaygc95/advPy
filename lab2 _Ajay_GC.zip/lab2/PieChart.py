__author__ = "Ajay GC"

from backend_lab2 import Backend
from matplotlib import pyplot as plt

class Graph:
    def __init__(self):
        self.Backend = Backend()

    def pie_chart(self):
        backend = self.Backend
        data = backend.parse()
        sorted_data = dict(sorted(data.items(),key=lambda item:item[1],reverse=True))
        count = 0
        percentage = []
        country = []
        explode = (0.1, 0, 0, 0,0,0,0,0,0,0)

        for cntry, pnt in sorted_data.items():
            if count < 10 and cntry != "European Union":
                percentage.append(pnt)
                country.append(cntry)
                count += 1

        plt.pie(
            percentage,labels=country,
            wedgeprops={'edgecolor':'white'},
            # autopct=lambda percentage: f'{percentage:.2f}%',
            autopct='%1.1f%%',
            shadow=True,
            explode=explode
        )
        plt.title("Top 10 Country by C02 Emission In 2017")
        plt.axis('equal')
        plt.show()

if __name__ == '__main__':
    graph = Graph()
    graph.pie_chart()